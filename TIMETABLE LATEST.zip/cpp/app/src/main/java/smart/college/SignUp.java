package smart.college;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.txtPassword);
        EditText confirmPassword = findViewById(R.id.password);
        SqliteHelper sqliteHelper = new SqliteHelper(this);

        findViewById(R.id.alreadyHaveAccount).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SignIn.class));
            }
        });


        findViewById(R.id.register_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (email.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Not Valid Email", Toast.LENGTH_SHORT).show();
                }

             else   if (password.getText().toString().equals(confirmPassword.getText().toString()) && (!password.getText().toString().isEmpty())) {

                    String UserName = email.getText().toString();
                    String Email = email.getText().toString();
                    String Password = password.getText().toString();

                    //Check in the database is there any user associated with  this email
                    if (!sqliteHelper.isEmailExists(Email)) {

                        //Email does not exist now add new user to database
                        sqliteHelper.addUser(new User(null, UserName, Email, Password));
                        Toast.makeText(getApplicationContext(), "User created successfully! Please Login ", Toast.LENGTH_SHORT).show();
                        finish();
                        startActivity(new Intent(getApplicationContext(), SignIn.class));

                    } else {
                        Toast.makeText(getApplicationContext(), "User already exists with same email  ", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(getApplicationContext(), "Password not match", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}