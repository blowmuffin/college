package smart.college.admin.add;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import smart.college.R;

public class AddTeacherActivity extends AppCompatActivity {

    int teacher_key = 0;
    int userId = 0;
    DatabaseReference mDatabaseReference;
    EditText teacher_name, teacher_email, teacher_mobile, teacher_address;
    Spinner teacher_class;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_teacher);
        teacher_name = findViewById(R.id.teacher_name);
        teacher_mobile = findViewById(R.id.teacher_mobile);
        teacher_email = findViewById(R.id.teacher_email);
        teacher_address = findViewById(R.id.teacher_address);
        teacher_class = findViewById(R.id.teacher_class);

        getUserId();

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Classes");

        List<String> classes = new ArrayList<>();
        classes.add("Select Classes");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override

            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {

                    Log.e("Data ", snapshot.toString());

                    ArrayList<HashMap> mapList = ((ArrayList<HashMap>) snapshot.getValue());

                    for (Map map : mapList) {
                        classes.add(map.get("class_name").toString());
                    }
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                teacher_class.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                teacher_class.setAdapter(adapter);
            }
        });


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Teacher");

        Query query = mDatabaseReference.orderByKey().limitToLast(1);

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot notepad : snapshot.getChildren()) {
                    teacher_key = Integer.parseInt(notepad.getKey().toString()) + 1;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.btnAddTeacher).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (teacher_name.getText().toString().isEmpty() || teacher_mobile.getText().toString().isEmpty() || teacher_email.getText().toString().isEmpty() || teacher_address.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Provide All Fields", Toast.LENGTH_SHORT).show();
                } else {

                    Map productMap = new HashMap();
                    productMap.put("teacher_name", teacher_name.getText().toString());
                    productMap.put("teacher_email", teacher_email.getText().toString());
                    productMap.put("teacher_mobile", teacher_mobile.getText().toString());
                    productMap.put("teacher_class", teacher_class.getSelectedItem().toString());
                    productMap.put("teacher_address", teacher_address.getText().toString());


                    mDatabaseReference.child(String.valueOf(teacher_key))
                            .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {

                                Toast.makeText(getApplicationContext(), "Teacher Added Successfully", Toast.LENGTH_SHORT).show();

                                Map user = new HashMap();
                                user.put("name", teacher_name.getText().toString());
                                user.put("email", teacher_email.getText().toString());
                                user.put("mobile", teacher_mobile.getText().toString());
                                user.put("type", "teacher");
                                user.put("password", teacher_name.getText().toString() + "@123");

                                addUser(user);

                            } else {
                                Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
                }

            }
        });

        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    public void getUserId() {

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
        Query query = mDatabaseReference.orderByKey().limitToLast(1);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot notepad : snapshot.getChildren()) {
                    userId = Integer.parseInt(notepad.getKey().toString()) + 1;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    public void addUser(Map user) {

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users");

        user.put("userId", String.valueOf(userId));

        mDatabaseReference.child(String.valueOf(userId))
                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {

                    Toast.makeText(getApplicationContext(), "User Added Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
                } else {
                    Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
    }

}
