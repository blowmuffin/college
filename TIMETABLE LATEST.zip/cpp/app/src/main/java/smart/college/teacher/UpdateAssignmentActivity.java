package smart.college.teacher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import smart.college.R;
import smart.college.session.UserSession;
import smart.college.student.StudentHomeActivity;

public class UpdateAssignmentActivity extends AppCompatActivity {

    EditText assignment_tittle, assignment_marks, assignment_questions, receivedMarks, assignment_solution;
    DatabaseReference mDatabaseReference;
    UserSession userSession;
    Map item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_assignment);
        item = (Map) getIntent().getExtras().get("item");
        Log.e("item ", item.toString());

        assignment_tittle = findViewById(R.id.tittle);
        assignment_marks = findViewById(R.id.marks);
        assignment_questions = findViewById(R.id.assignment_questions);
        assignment_solution = findViewById(R.id.assignment_solution);
        receivedMarks = findViewById(R.id.receivedMarks);
        userSession = new UserSession(getApplicationContext());

        checkAssignmentIsUpdatedOrNot();

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("AssignmentsSolutions");

        assignment_tittle.setText(item.get("tittle").toString());
        assignment_marks.setText(item.get("marks").toString());
        assignment_questions.setText(item.get("questions").toString());
        assignment_solution.setText(item.get("solution").toString());
        receivedMarks.setText(item.get("receivedMarks").toString());

        findViewById(R.id.submit_assignment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Map productMap = new HashMap();

                productMap.put("tittle", assignment_tittle.getText().toString());
                productMap.put("marks", assignment_marks.getText().toString());
                productMap.put("questions", assignment_questions.getText().toString());
                productMap.put("solution", assignment_solution.getText().toString());
                productMap.put("teacher_name", item.get("teacher_name"));
                productMap.put("teacher_email", item.get("teacher_email"));
                productMap.put("teacher_id", item.get("teacher_id"));
                productMap.put("student_name", item.get("student_name"));
                productMap.put("student_email", item.get("student_email"));
                productMap.put("student_id", item.get("student_id"));
                productMap.put("receivedMarks", receivedMarks.getText().toString());
                productMap.put("status", "resultCompleted");

                mDatabaseReference.child(String.valueOf(item.get("key")))
                        .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Assignment Updated Successfully", Toast.LENGTH_SHORT).show();
                          //  startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
                        } else {
                            Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });


    }

    private void checkAssignmentIsUpdatedOrNot() {


        if (item.get("receivedMarks").equals("0") == false) {
            findViewById(R.id.submit_assignment).setClickable(false);
            findViewById(R.id.submit_assignment).setEnabled(false);
            findViewById(R.id.submit).setClickable(false);
            findViewById(R.id.submit).setEnabled(false);
            receivedMarks.setInputType(InputType.TYPE_NULL);
        }

        findViewById(R.id.img_go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
       // startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
    }
}