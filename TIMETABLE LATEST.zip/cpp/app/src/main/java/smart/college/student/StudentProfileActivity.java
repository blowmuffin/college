package smart.college.student;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import smart.college.R;
import smart.college.session.UserSession;
// import smart.college.teacher.TeacherHomePage;

public class StudentProfileActivity extends AppCompatActivity {


    int student_key = 0;
    int userId = 0;
    DatabaseReference mDatabaseReference;
    EditText student_name, student_email, student_mobile, student_address, student_class;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);
        student_name = findViewById(R.id.student_name);
        student_mobile = findViewById(R.id.student_mobile);
        student_email = findViewById(R.id.student_email);
        student_address = findViewById(R.id.student_address);
        student_class = findViewById(R.id.student_class);

        UserSession userSession = new UserSession(getApplicationContext());


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Student");

        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    HashMap data = (HashMap) dataSnapshot.getValue();

                    if (data.get("student_email").equals(userSession.getEmail())) {
                        student_class.setText(data.get("student_class").toString());
                        student_name.setText(data.get("student_name").toString());
                        student_mobile.setText(data.get("student_mobile").toString());
                        student_email.setText(data.get("student_email").toString());
                        student_address.setText(data.get("student_address").toString());
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), StudentHomeActivity.class));
    }
}