//package smart.college.admin.add;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.View;
//import android.widget.ArrayAdapter;
//import android.widget.EditText;
//import android.widget.Spinner;
//import android.widget.Toast;
//
//import com.google.android.gms.tasks.OnCompleteListener;
//import com.google.android.gms.tasks.Task;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.Query;
//import com.google.firebase.database.ValueEventListener;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import smart.college.R;
//import smart.college.session.UserSession;
//import smart.college.teacher.TeacherHomePage;
//
//public class AddStudentActivity extends AppCompatActivity {
//
//
//    int student_key = 0;
//    int userId = 0;
//    DatabaseReference mDatabaseReference;
//    EditText student_name, student_email, student_mobile, student_address;
//    Spinner student_class;
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_add_student);
//
//        student_name = findViewById(R.id.student_name);
//        student_mobile = findViewById(R.id.student_mobile);
//        student_email = findViewById(R.id.student_email);
//        student_address = findViewById(R.id.student_address);
//        student_class = findViewById(R.id.student_class);
//
//        getUserId();
//        Query query;
//
//        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Classes");
//        List<String> classes = new ArrayList<>();
//        classes.add("Select Classes");
//        mDatabaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                if (snapshot.exists()) {
//
//                    Log.e("Data ", snapshot.toString());
//
//                    ArrayList<HashMap> mapList = ((ArrayList<HashMap>) snapshot.getValue());
//
//                    for (Map map : mapList) {
//                        classes.add(map.get("class_name").toString());
//                    }
//                }
//
//                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
//                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//                student_class.setAdapter(adapter);
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
//                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
//                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//                student_class.setAdapter(adapter);
//            }
//        });
//
//
//        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Student");
//        query = mDatabaseReference.orderByKey().limitToLast(1);
//        query.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                for (DataSnapshot notepad : snapshot.getChildren()) {
//                    student_key = Integer.parseInt(notepad.getKey().toString()) + 1;
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//
//        findViewById(R.id.btnAddStudent).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                if (student_name.getText().toString().isEmpty() || student_mobile.getText().toString().isEmpty() || student_email.getText().toString().isEmpty() || student_address.getText().toString().isEmpty()) {
//                    Toast.makeText(getApplicationContext(), "Provide All Fields", Toast.LENGTH_SHORT).show();
//                } else {
//
//                    Map productMap = new HashMap();
//                    productMap.put("student_name", student_name.getText().toString());
//                    productMap.put("student_email", student_email.getText().toString());
//                    productMap.put("student_mobile", student_mobile.getText().toString());
//                    productMap.put("student_class", student_class.getSelectedItem().toString());
//                    productMap.put("student_address", student_address.getText().toString());
//
//
//                    mDatabaseReference.child(String.valueOf(student_key))
//                            .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
//                        @Override
//                        public void onComplete(@NonNull Task<Void> task) {
//                            if (task.isSuccessful()) {
//
//                                Toast.makeText(getApplicationContext(), "Class Added Successfully", Toast.LENGTH_SHORT).show();
//                                Map user = new HashMap();
//                                user.put("name", student_name.getText().toString());
//                                user.put("email", student_email.getText().toString());
//                                user.put("mobile", student_mobile.getText().toString());
//                                user.put("password", student_name.getText().toString() + "@123");
//                                user.put("type", "student");
//
//                                addUser(user);
//
//                            } else {
//                                Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();
//
//                            }
//                        }
//                    });
//                }
//
//            }
//        });
//
//
//        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });
//
//
//    }
//
//
//    public void getUserId() {
//
//        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
//        Query query = mDatabaseReference.orderByKey().limitToLast(1);
//        query.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                for (DataSnapshot notepad : snapshot.getChildren()) {
//                    userId = Integer.parseInt(notepad.getKey().toString()) + 1;
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//
//    }
//
//    public void addUser(Map user) {
//
//        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
//
//        user.put("userId", String.valueOf(userId));
//
//        mDatabaseReference.child(String.valueOf(userId))
//                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
//            @Override
//            public void onComplete(@NonNull Task<Void> task) {
//                if (task.isSuccessful()) {
//
//                    Toast.makeText(getApplicationContext(), "User Added Successfully", Toast.LENGTH_SHORT).show();
//                    startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
//                } else {
//                    Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();
//
//                }
//            }
//        });
//
//
//    }
//
//
//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//        if (new UserSession(getApplicationContext()).getTemp().equalsIgnoreCase("admin")) {
//            finish();
//            startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
//        }else {
//            finish();
//            startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
//
//        }
//    }
//
//}
