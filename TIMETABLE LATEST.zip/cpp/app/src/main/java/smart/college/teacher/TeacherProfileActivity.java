package smart.college.teacher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import smart.college.R;
import smart.college.session.UserSession;

public class TeacherProfileActivity extends AppCompatActivity {


    int teacher_key = 0;
    int userId = 0;
    DatabaseReference mDatabaseReference;
    EditText teacher_name, teacher_email, teacher_mobile, teacher_address, teacher_class_name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_profile);

        teacher_name = findViewById(R.id.teacher_name);
        teacher_mobile = findViewById(R.id.teacher_mobile);
        teacher_email = findViewById(R.id.teacher_email);
        teacher_address = findViewById(R.id.teacher_address);
        teacher_class_name = findViewById(R.id.teacher_class_room);

        UserSession userSession = new UserSession(getApplicationContext());


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Teacher");


        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    HashMap data = (HashMap) dataSnapshot.getValue();

                    if (data.get("teacher_email").equals(userSession.getEmail())) {
                        teacher_class_name.setText(data.get("teacher_class").toString());
                        teacher_name.setText(data.get("teacher_name").toString());
                        teacher_mobile.setText(data.get("teacher_mobile").toString());
                        teacher_email.setText(data.get("teacher_email").toString());
                        teacher_address.setText(data.get("teacher_address").toString());
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        // startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
    }
}