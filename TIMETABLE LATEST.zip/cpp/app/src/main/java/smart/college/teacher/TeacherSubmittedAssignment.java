package smart.college.teacher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import smart.college.R;
import smart.college.admin.view.StudentAdapter;
import smart.college.admin.view.StudentAdapter1;
import smart.college.session.UserSession;
// import smart.college.teacher.TeacherHomePage;

public class TeacherSubmittedAssignment extends AppCompatActivity {

    DatabaseReference mDatabaseReference;
    Spinner all_assignments;
    String teacher_class_name;
    int currentTab = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_submitted_assignment);

        UserSession userSession = new UserSession(getApplicationContext());
        all_assignments = findViewById(R.id.all_assignments);
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Teacher");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Map student = (Map) dataSnapshot.getValue();
                    if (student.get("teacher_email").toString().equalsIgnoreCase(userSession.getEmail())) {
                        Log.e("Teacher ID ", dataSnapshot.toString());
                        teacher_class_name = student.get("teacher_class").toString();

                        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Assignments");
                        List<String> classes = new ArrayList<>();
                        classes.add("Select Assignment");
                        mDatabaseReference.addValueEventListener(new ValueEventListener() {
                            @Override

                            public void onDataChange(@NonNull DataSnapshot snapshot) {

                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    Map assignment = (Map) dataSnapshot.getValue();
                                    if (assignment.get("class").toString().equalsIgnoreCase(teacher_class_name)) {
                                        classes.add(assignment.get("tittle").toString());
                                    }
                                }

                                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                all_assignments.setAdapter(adapter);

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
                                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                all_assignments.setAdapter(adapter);
                            }
                        });


                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("All Student Assignments"));
//        tabLayout.addTab(tabLayout.newTab().setText("Missed"));


        tabLayout.setOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                if (tab.getPosition() == 0) {
                    currentTab = 0;
                    findViewById(R.id.hide).setVisibility(View.GONE);
                    findViewById(R.id.hide1).setVisibility(View.GONE);
                }
                if (tab.getPosition() == 1) {
                    currentTab = 1;
                    findViewById(R.id.hide).setVisibility(View.VISIBLE);
                    findViewById(R.id.hide1).setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        getStudentList();

    }


    public void getStudentList() {

        all_assignments.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (all_assignments.getSelectedItem().toString().equalsIgnoreCase("Select Assignment") == false) {

                    ArrayList<HashMap> studentList = new ArrayList<>();

                    mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("AssignmentsSolutions");
                    mDatabaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                HashMap assignment = (HashMap) dataSnapshot.getValue();
                                if (assignment.get("tittle").equals(all_assignments.getSelectedItem().toString())) {
                                    assignment.put("key", dataSnapshot.getKey());
                                    studentList.add(assignment);
                                }
                            }

                            if (studentList.isEmpty() == false) {

                                RecyclerView recyclerView = findViewById(R.id.recycle_view);
                                StudentAdapter1 itemAdapter = new StudentAdapter1(studentList, getApplicationContext());
                                GridLayoutManager gridLayout = new GridLayoutManager(getApplicationContext(), 1);
                                recyclerView.setAdapter(itemAdapter);
                                recyclerView.setLayoutManager(gridLayout);

                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        findViewById(R.id.img_go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        // startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
    }
}