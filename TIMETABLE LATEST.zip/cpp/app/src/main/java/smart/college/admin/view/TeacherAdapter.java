package smart.college.admin.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import smart.college.R;


public class TeacherAdapter extends RecyclerView.Adapter<TeacherAdapter.ItemViewHolder> {

    private ArrayList<HashMap> mItemList;
    private Context mcontext;

    public TeacherAdapter(@NonNull ArrayList<HashMap> ItemList, Context context) {
        this.mItemList = ItemList;
        this.mcontext = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.teacher_item, parent, false);
        return new ItemViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {

        final Map item = mItemList.get(position);
        if (item != null) {
            Log.e("Map", item.toString());
            holder.teacher_no.setText("Mobile: " + item.get("teacher_mobile").toString());
            holder.teacher_name.setText("Name: " + item.get("teacher_name").toString());
            holder.teacher_class.setText("Class : " + item.get("teacher_class").toString());
            holder.teacher_email.setText("Email : " + item.get("teacher_email").toString());
        }

    }// End of binder function


    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView teacher_name, teacher_no, teacher_email, teacher_class;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            teacher_name = itemView.findViewById(R.id.teacher_name);
            teacher_no = itemView.findViewById(R.id.teacher_mobile);
            teacher_email = itemView.findViewById(R.id.teacher_email);
            teacher_class = itemView.findViewById(R.id.teacher_class);
        }
    }
}
