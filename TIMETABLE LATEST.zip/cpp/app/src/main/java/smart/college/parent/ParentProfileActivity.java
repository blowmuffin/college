package smart.college.parent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

import smart.college.R;
import smart.college.session.UserSession;
//import smart.college.teacher.TeacherHomePage;

public class ParentProfileActivity extends AppCompatActivity {
    int parent_key = 0;
    DatabaseReference mDatabaseReference;
    EditText parent_name, parent_email, parent_mobile, parent_details, parent_student;
    int userId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_profile);
        parent_name = findViewById(R.id.parent_name);
        parent_mobile = findViewById(R.id.parent_mobile);
        parent_email = findViewById(R.id.parent_email);
        parent_details = findViewById(R.id.parent_details);
        parent_student = findViewById(R.id.parent_student);

        UserSession userSession = new UserSession(getApplicationContext());


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Parent");


        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    HashMap data = (HashMap) dataSnapshot.getValue();

                    if (data.get("parent_email").equals(userSession.getHomeDelivery())) {
                        parent_name.setText(data.get("parent_name").toString());
                        parent_mobile.setText(data.get("parent_mobile").toString());
                        parent_email.setText(data.get("parent_email").toString());
                        parent_details.setText(data.get("parent_details").toString());
                        parent_student.setText(data.get("parent_student").toString());
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), ParentHomeActivity.class));
    }

}