package smart.college.admin.add;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import smart.college.R;

public class AddParentActivity extends AppCompatActivity {

    int parent_key = 0;
    DatabaseReference mDatabaseReference;
    EditText parent_name, parent_email, parent_mobile, parent_details;
    Spinner parent_student;
    int userId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parent);
        parent_name = findViewById(R.id.parent_name);
        parent_mobile = findViewById(R.id.parent_mobile);
        parent_email = findViewById(R.id.parent_email);
        parent_details = findViewById(R.id.parent_details);
        parent_student = findViewById(R.id.parent_student);


        getUserId();

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Student");

        List<String> classes = new ArrayList<>();
        classes.add("Select Student");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override

            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {

                    Log.e("Data ", snapshot.toString());

                    ArrayList<HashMap> mapList = ((ArrayList<HashMap>) snapshot.getValue());

                    for (Map map : mapList) {
                        classes.add(map.get("student_name").toString());
                    }
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                parent_student.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                parent_student.setAdapter(adapter);
            }
        });


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Parent");

        Query query = mDatabaseReference.orderByKey().limitToLast(1);

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot notepad : snapshot.getChildren()) {
                    parent_key = Integer.parseInt(notepad.getKey().toString()) + 1;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.btnAddParent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (parent_name.getText().toString().isEmpty() || parent_mobile.getText().toString().isEmpty() || parent_email.getText().toString().isEmpty() || parent_details.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Provide All Fields", Toast.LENGTH_SHORT).show();
                } else {

                    Map productMap = new HashMap();
                    productMap.put("parent_name", parent_name.getText().toString());
                    productMap.put("parent_email", parent_email.getText().toString());
                    productMap.put("parent_mobile", parent_mobile.getText().toString());
                    productMap.put("parent_student", parent_student.getSelectedItem().toString());
                    productMap.put("parent_details", parent_details.getText().toString());


                    mDatabaseReference.child(String.valueOf(parent_key))
                            .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {

                                Toast.makeText(getApplicationContext(), "Class Added Successfully", Toast.LENGTH_SHORT).show();

                                Map user = new HashMap();
                                user.put("name", parent_name.getText().toString());
                                user.put("email", parent_email.getText().toString());
                                user.put("mobile", parent_mobile.getText().toString());
                                user.put("type", "parent");
                                user.put("password", parent_name.getText().toString() + "@123");

                                addUser(user);

                            } else {
                                Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
                }

            }
        });

        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }


    public void getUserId() {

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
        Query query = mDatabaseReference.orderByKey().limitToLast(1);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot notepad : snapshot.getChildren()) {
                    userId = Integer.parseInt(notepad.getKey().toString()) + 1;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    public void addUser(Map user) {

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users");

        user.put("userId", String.valueOf(userId));

        mDatabaseReference.child(String.valueOf(userId))
                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {

                    Toast.makeText(getApplicationContext(), "User Added Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
                } else {
                    Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
    }

}
