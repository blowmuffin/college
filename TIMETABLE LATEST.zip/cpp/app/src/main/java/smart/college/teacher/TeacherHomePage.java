//package smart.college.teacher;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import smart.college.R;
//import smart.college.SignIn;
//import smart.college.admin.add.AddStudentActivity;
//import smart.college.admin.view.ViewStudentActivity;
//import smart.college.ViewTimeTableActivity;
//import smart.college.session.UserSession;
//
//public class TeacherHomePage extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_home_page);
//
//
////        findViewById(R.id.btnAddStudent).setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                finish();
////                startActivity(new Intent(getApplicationContext(), AddStudentActivity.class));
////            }
//        });
////        findViewById(R.id.crd_view_time_table).setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                startActivity(new Intent(getApplicationContext(), ViewTimeTableActivity.class));
////            }
////        });
//
//
////        findViewById(R.id.btnViewStudents).setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                finish();
////                startActivity(new Intent(getApplicationContext(), ViewStudentActivity.class));
////            }
////        });
//
//
//        findViewById(R.id.view_attendance).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(), ViewAttendacneActivity.class));
//            }
//        });
//
//
////        findViewById(R.id.new_assignment).setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                startActivity(new Intent(getApplicationContext(), TeacherNewAssignment.class));
////            }
////        });
//
//
//        findViewById(R.id.mark_attendance).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(), MarkAttendanceActivity.class));
//            }
//        });
//
////        findViewById(R.id.sub_assignment).setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                startActivity(new Intent(getApplicationContext(), TeacherSubmittedAssignment.class));
////            }
////        });
//
//
//        findViewById(R.id.crd_profile).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), TeacherProfileActivity.class));
//            }
//        });
//
//        findViewById(R.id.crd_logout).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                UserSession userSession = new UserSession(getApplicationContext());
//                userSession.removeUser();
//                startActivity(new Intent(getApplicationContext(), SignIn.class));
//            }
//        });
//
//
//    }
//}