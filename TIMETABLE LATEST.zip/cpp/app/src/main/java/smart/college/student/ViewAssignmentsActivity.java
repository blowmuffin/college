package smart.college.student;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;

import smart.college.R;
import smart.college.admin.add.AdminHomeActivity;
import smart.college.admin.view.SubjectAdapter;
import smart.college.parent.ParentHomeActivity;
import smart.college.session.UserSession;

public class ViewAssignmentsActivity extends AppCompatActivity {

    DatabaseReference mDatabaseReference;
    ArrayList<Map> allClasses;
    String student_class_name;
    UserSession userSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_assignments);
        userSession = new UserSession(getApplicationContext());

        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
            }
        });


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Student");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Map student = (Map) dataSnapshot.getValue();
                    if (student.get("student_email").toString().equalsIgnoreCase(userSession.getEmail())) {
                        Log.e("Student ID ", dataSnapshot.toString());
                        student_class_name = student.get("student_class").toString();
                        getAllAssigments(student_class_name);
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void getAllAssigments(String student_class_name) {

        allClasses = new ArrayList<Map>();

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Assignments");

        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                if (allClasses.isEmpty() == false) {
                    allClasses.clear();
                }


                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Map assignment = (Map) dataSnapshot.getValue();
                    if (assignment.get("class").toString().equalsIgnoreCase(student_class_name)) {
                        Log.e("Ass ", dataSnapshot.toString());
                        allClasses.add(assignment);
                    }
                }


                Log.e("all Adss", allClasses.toString());

                RecyclerView recyclerView = findViewById(R.id.recycle_view);
                AssignmentAdapter itemAdapter = new AssignmentAdapter(allClasses, getApplicationContext());
                GridLayoutManager gridLayout = new GridLayoutManager(getApplicationContext(), 1);
                recyclerView.setAdapter(itemAdapter);
                recyclerView.setLayoutManager(gridLayout);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
            }
        });


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        if (userSession.getTemp().equalsIgnoreCase("student")) {
            startActivity(new Intent(getApplicationContext(), StudentHomeActivity.class));
        } else {
            startActivity(new Intent(getApplicationContext(), ParentHomeActivity.class));
        }
//        if (role.equalsIgnoreCase("admin"))
//            startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
//        else
//            startActivity(new Intent(getApplicationContext(), WorkerHomeActivity.class));
    }

}
