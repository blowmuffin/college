package smart.college.admin.add;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import smart.college.R;
import smart.college.SignIn;
import smart.college.admin.view.VIewParentsActivity;
import smart.college.admin.view.ViewClassesActivity;
import smart.college.admin.view.ViewStudentActivity;
import smart.college.admin.view.ViewSubjectsActivity;
import smart.college.admin.view.ViewTeacherActivity;
import smart.college.ViewTimeTableActivity;
import smart.college.session.UserSession;

public class AdminHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);


//        findViewById(R.id.btnAddClass).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), AddClassRoom.class));
//            }
//        });
//
//
//       findViewById(R.id.btnViewClasses).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), ViewClassesActivity.class));
//            }
//        });


        findViewById(R.id.btnAddSubject).setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View v) {
              finish();
               startActivity(new Intent(getApplicationContext(), AddSubjectActivity.class));
            }
        });


        findViewById(R.id.btnViewSubjects).setOnClickListener(new View.OnClickListener() {
        @Override
          public void onClick(View v) {
                finish();
                startActivity(new Intent(getApplicationContext(), ViewSubjectsActivity.class));
            }
        });


       findViewById(R.id.crd_generate).setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
                finish();
                startActivity(new Intent(getApplicationContext(), GeneratTimeTableActivity.class));
            }
        });


        findViewById(R.id.crd_view_time_table).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(getApplicationContext(), ViewTimeTableActivity.class));
            }
        });

//        findViewById(R.id.btnAddStudent).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), AddStudentActivity.class));
//            }
//        });


//        findViewById(R.id.btnViewStudents).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), ViewStudentActivity.class));
//            }
//        });


//        findViewById(R.id.btnAddTeacher).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), AddTeacherActivity.class));
//            }
//        });
//
//
//        findViewById(R.id.btnViewTeachers).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), ViewTeacherActivity.class));
//            }
//        });


//        findViewById(R.id.btnAddParent).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), AddParentActivity.class));
//            }
//        });
//
//
//        findViewById(R.id.btnViewParents).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                startActivity(new Intent(getApplicationContext(), VIewParentsActivity.class));
//            }
//        });


        findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                UserSession userSession = new UserSession(getApplicationContext());
                userSession.removeUser();
                startActivity(new Intent(getApplicationContext(), SignIn.class));
            }
        });


    }

}