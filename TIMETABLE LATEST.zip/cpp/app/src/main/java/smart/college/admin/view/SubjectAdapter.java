package smart.college.admin.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import smart.college.R;


public class SubjectAdapter extends RecyclerView.Adapter<SubjectAdapter.ItemViewHolder> {

    private ArrayList<HashMap> mItemList;
    private Context mcontext;

    public SubjectAdapter(@NonNull ArrayList<HashMap> ItemList, Context context) {
        this.mItemList = ItemList;
        this.mcontext = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.subject_item, parent, false);
        return new ItemViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {

        final Map item = mItemList.get(position);
        if (item != null) {
            Log.e("Map", item.toString());
            holder.subject_no.setText("Code: " + item.get("subject_code").toString());
            holder.subject_name.setText("Name: " + item.get("subject_name").toString());
            holder.subject_class.setText("Class : " + item.get("subject_class").toString());
            holder.subject_location.setText("Details : " + item.get("subject_details").toString());
        }
    }// End of binder function


    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView subject_name, subject_no, subject_location, subject_class;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            subject_name = itemView.findViewById(R.id.subject_name);
            subject_no = itemView.findViewById(R.id.subject_code);
            subject_location = itemView.findViewById(R.id.subject_details);
            subject_class = itemView.findViewById(R.id.subject_class);
        }
    }
}
