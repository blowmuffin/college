package smart.college.teacher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import smart.college.R;
import smart.college.admin.add.AdminHomeActivity;
import smart.college.session.UserSession;

public class MarkAttendanceActivity extends AppCompatActivity {

    String teacher_class_name;
    DatabaseReference mDatabaseReference;
    Spinner all_students_spinner;
    List<String> student_names;
    List<Map> students;
    TextView select_date_txt;
    String attendanceDate;
    DatePickerDialog datePickerDialog;
    int attendance_key = 0;
    UserSession userSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mark_attendance);

        all_students_spinner = findViewById(R.id.all_students_spinner);
        student_names = new ArrayList<>();
        students = new ArrayList<>();
        select_date_txt = findViewById(R.id.select_date_txt);

        userSession = new UserSession(getApplicationContext());
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Teacher");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Map student = (Map) dataSnapshot.getValue();
                    if (student.get("teacher_email").toString().equalsIgnoreCase(userSession.getEmail())) {
                        Log.e("Teacher ID ", dataSnapshot.toString());
                        teacher_class_name = student.get("teacher_class").toString();

                        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Student");

                        mDatabaseReference.addValueEventListener(new ValueEventListener() {
                            @Override

                            public void onDataChange(@NonNull DataSnapshot snapshot) {

                                student_names.clear();
                                student_names.add("Select Student");
                                students.add(new HashMap());

                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    Map student = (Map) dataSnapshot.getValue();
                                    if (student.get("student_class").toString().equalsIgnoreCase(teacher_class_name)) {
                                        student_names.add(student.get("student_name").toString());
                                        students.add(student);
                                    }
                                }

                                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, student_names);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                all_students_spinner.setAdapter(adapter);

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
                                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, student_names);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                all_students_spinner.setAdapter(adapter);
                            }
                        });


                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!" + error.toString(), Toast.LENGTH_LONG).show();
            }
        });


        findViewById(R.id.select_date).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // current year
                int mMonth = c.get(Calendar.MONTH); // current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day
                // date picker dialog
                datePickerDialog = new DatePickerDialog(MarkAttendanceActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // set day of month , month and year value in the edit text
                                attendanceDate = (dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                                select_date_txt.setText(attendanceDate);
                                getAttendanceKey();
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });


        findViewById(R.id.btnMarkPresent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                markAttendance(1);
            }
        });


        findViewById(R.id.btnMarkAbsent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                markAttendance(0);

            }
        });

        findViewById(R.id.img_go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }


    public void getAttendanceKey() {
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Attendance").child(attendanceDate);

        Query query = mDatabaseReference.orderByKey().limitToLast(1);

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot notepad : snapshot.getChildren()) {
                    attendance_key = Integer.parseInt(notepad.getKey().toString());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    public void markAttendance(int status) {
        String currentStudent = all_students_spinner.getSelectedItem().toString();
        int index = student_names.indexOf(currentStudent);

        if (index == 0) {
            return;
        }


        Map productMap = new HashMap();
        productMap.put("class", teacher_class_name);
        productMap.put("teacher_name", userSession.getFirstName());
        productMap.put("teacher_email", userSession.getEmail());
        productMap.put("teacher_id", userSession.getCustomerId());
        productMap.put("student_name", students.get(index).get("student_name"));
        productMap.put("student_email", students.get(index).get("student_email"));
        productMap.put("status", status);

        mDatabaseReference.child(String.valueOf(attendance_key + 1))
                .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(getApplicationContext(), "Attendance Marked SUccessfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();

                }
            }
        });


        findViewById(R.id.select_date).setClickable(false);

        student_names.remove(index);
        students.remove(index);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, student_names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        all_students_spinner.setAdapter(adapter);


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        // startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
    }
}