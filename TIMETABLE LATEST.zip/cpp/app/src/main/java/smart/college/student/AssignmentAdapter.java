package smart.college.student;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import smart.college.R;


public class AssignmentAdapter extends RecyclerView.Adapter<AssignmentAdapter.ItemViewHolder> {

    private ArrayList<Map> mItemList;
    private Context mcontext;

    public AssignmentAdapter(@NonNull ArrayList<Map> ItemList, Context context) {
        this.mItemList = ItemList;
        this.mcontext = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.assignment_item, parent, false);
        return new ItemViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {

        final Map item = mItemList.get(position);
        if (item != null) {
            Log.e("Map", item.toString());
            holder.assignment_name.setText("Name: " + item.get("tittle").toString());
            holder.assignment_marks.setText("Marks: " + item.get("marks").toString());
            holder.assignment_questions.setText("Questions : " + item.get("questions").toString());
            holder.assignment_view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mcontext, ViewAndSolveAssignmentActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("item", (Serializable) item);
                    mcontext.startActivity(intent);
                }
            });
//            holder.student_email.setText("Email : " + item.get("student_email").toString());
        }

    }// End of binder function


    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView assignment_name, assignment_marks, assignment_questions;
        private Button assignment_view;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            assignment_name = itemView.findViewById(R.id.assignment_name);
            assignment_marks = itemView.findViewById(R.id.assignment_marks);
            assignment_questions = itemView.findViewById(R.id.assignment_question);
            assignment_view = itemView.findViewById(R.id.assignment_view);
        }
    }
}
