package smart.college.admin.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import smart.college.R;


public class ClassAdapter extends RecyclerView.Adapter<ClassAdapter.ItemViewHolder> {

    private ArrayList<HashMap> mItemList;
    private Context mcontext;

    public ClassAdapter(@NonNull ArrayList<HashMap> ItemList, Context context) {
        this.mItemList = ItemList;
        this.mcontext = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.class_item, parent, false);
        return new ItemViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {

        final Map item = mItemList.get(position);
        holder.class_no.setText("Code: " + item.get("class_no").toString());
        holder.class_name.setText("Name: " + item.get("class_name").toString());
        holder.class_location.setText("Location: " + item.get("class_location").toString());

    }// End of binder function

    @Override
    public int getItemCount() {
        return mItemList.size();
    }


    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView class_name, class_no, class_location;

        public ItemViewHolder(@NonNull View itemView) {

            super(itemView);
            class_name = itemView.findViewById(R.id.class_name);
            class_no = itemView.findViewById(R.id.class_no);
            class_location = itemView.findViewById(R.id.class_location);
        }

    }
}
