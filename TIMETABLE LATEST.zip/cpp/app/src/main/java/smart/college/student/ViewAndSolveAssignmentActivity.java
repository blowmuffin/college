package smart.college.student;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import smart.college.R;
import smart.college.admin.add.AdminHomeActivity;
import smart.college.parent.ParentHomeActivity;
import smart.college.session.UserSession;

public class ViewAndSolveAssignmentActivity extends AppCompatActivity {


    EditText assignment_tittle, assignment_marks, assignment_questions, receivedMarks, assignment_solution;
    int ass_submission_key = 0;
    DatabaseReference mDatabaseReference;
    UserSession userSession;
    Map item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_and_solve_assignment);

        item = (Map) getIntent().getExtras().get("item");
        Log.e("item ", item.toString());

        assignment_tittle = findViewById(R.id.tittle);
        assignment_marks = findViewById(R.id.marks);
        assignment_questions = findViewById(R.id.assignment_questions);
        assignment_solution = findViewById(R.id.assignment_solution);
        receivedMarks = findViewById(R.id.receivedMarks);
        userSession = new UserSession(getApplicationContext());

        checkAssignmentIsSubmittedOrNot();

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("AssignmentsSolutions");

        Query query = mDatabaseReference.orderByKey().limitToLast(1);

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot notepad : snapshot.getChildren()) {
                    ass_submission_key = Integer.parseInt(notepad.getKey().toString()) + 1;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


        assignment_tittle.setText(item.get("tittle").toString());
        assignment_marks.setText(item.get("marks").toString());
        assignment_questions.setText(item.get("questions").toString());

        findViewById(R.id.submit_assignment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Map productMap = new HashMap();

                productMap.put("tittle", assignment_tittle.getText().toString());
                productMap.put("marks", assignment_marks.getText().toString());
                productMap.put("questions", assignment_questions.getText().toString());
                productMap.put("solution", assignment_solution.getText().toString());
                productMap.put("teacher_name", item.get("teacher_name"));
                productMap.put("teacher_email", item.get("teacher_email"));
                productMap.put("teacher_id", item.get("teacher_id"));
                productMap.put("student_name", userSession.getFirstName());
                productMap.put("student_email", userSession.getEmail());
                productMap.put("student_id", userSession.getCustomerId());
                productMap.put("receivedMarks", receivedMarks.getText().toString());
                productMap.put("status", "resultPending");

                mDatabaseReference.child(String.valueOf(ass_submission_key))
                        .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Assignment Submitted Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), StudentHomeActivity.class));
                        } else {
                            Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });


        if (userSession.getTemp().equalsIgnoreCase("parent")) {
            findViewById(R.id.submit_assignment).setVisibility(View.GONE);
            assignment_solution.setInputType(InputType.TYPE_NULL);
        }


    }

    private void checkAssignmentIsSubmittedOrNot() {

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("AssignmentsSolutions");

        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                    Map solutions = (Map) dataSnapshot.getValue();

                    if (solutions.get("student_email").toString().equalsIgnoreCase(userSession.getEmail())
                            && solutions.get("tittle").toString().equalsIgnoreCase(item.get("tittle").toString())) {

                        findViewById(R.id.submit_assignment).setClickable(false);
                        findViewById(R.id.submit_assignment).setEnabled(false);
                        findViewById(R.id.submit).setClickable(false);
                        findViewById(R.id.submit).setEnabled(false);
                        assignment_solution.setInputType(InputType.TYPE_NULL);

                        receivedMarks.setText(solutions.get("receivedMarks").toString());
                        assignment_solution.setText(solutions.get("solution").toString());
                        return;
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();

            }
        });


        findViewById(R.id.img_go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        if (userSession.getTemp().equalsIgnoreCase("parent")) {
            startActivity(new Intent(getApplicationContext(), ParentHomeActivity.class));
        } else {
            startActivity(new Intent(getApplicationContext(), StudentHomeActivity.class));
        }
    }
}