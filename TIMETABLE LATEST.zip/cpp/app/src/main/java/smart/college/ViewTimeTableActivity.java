package smart.college;

import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.util.HashMap;

public class ViewTimeTableActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_time_table);

        // Initialize views
        TableLayout tableLayout = findViewById(R.id.tableLayout);

        // Retrieve timetable data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("TimetablePrefs", MODE_PRIVATE);
        String json = sharedPreferences.getString("timetable", "");

        // Convert JSON string to HashMap using Gson
        Gson gson = new Gson();
        HashMap<String, String> timetable = gson.fromJson(json, HashMap.class);

        // Display timetable
        displayTimeTable(tableLayout, timetable);
    }

    // Method to display timetable in TableLayout
    private void displayTimeTable(TableLayout tableLayout, HashMap<String, String> timetable) {
        for (String key : timetable.keySet()) {
            String value = timetable.get(key);
            String[] parts = value.split(", ");
            String day = parts[0];
            String time = parts[1];
            String subject = parts[2];

            // Create TableRow
            TableRow row = new TableRow(this);
            TableRow.LayoutParams rowParams = new TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT);
            row.setLayoutParams(rowParams);
            row.setGravity(Gravity.CENTER);

            // Create TextViews for each cell
            TextView dayTextView = createTextView(day);
            TextView timeTextView = createTextView(time);
            TextView subjectTextView = createTextView(subject);

            // Add TextViews to TableRow
            row.addView(dayTextView);
            row.addView(timeTextView);
            row.addView(subjectTextView);

            // Add TableRow to TableLayout
            tableLayout.addView(row);

            // Add horizontal divider between rows
            if (tableLayout.getChildCount() > 1) {
                Drawable drawable = getResources().getDrawable(R.drawable.table_border);
                row.setBackground(drawable);
            }
        }
    }

    // Helper method to create TextView with common styling
    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(16, 16, 16, 16);
        textView.setTextColor(getResources().getColor(android.R.color.black));
        textView.setGravity(Gravity.CENTER);
        return textView;
    }
}
