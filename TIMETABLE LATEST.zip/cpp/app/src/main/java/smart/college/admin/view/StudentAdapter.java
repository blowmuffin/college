package smart.college.admin.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import smart.college.R;


public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ItemViewHolder> {

    private ArrayList<HashMap> mItemList;
    private Context mcontext;

    public StudentAdapter(@NonNull ArrayList<HashMap> ItemList, Context context) {
        this.mItemList = ItemList;
        this.mcontext = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_item, parent, false);
        return new ItemViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {

        final Map item = mItemList.get(position);
        if (item != null) {
            Log.e("Map", item.toString());
            holder.student_no.setText("Mobile: " + item.get("student_mobile").toString());
            holder.student_name.setText("Name: " + item.get("student_name").toString());
            holder.student_class.setText("Class : " + item.get("student_class").toString());
            holder.student_email.setText("Email : " + item.get("student_email").toString());
        }

    }// End of binder function


    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView student_name, student_no, student_email, student_class;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            student_name = itemView.findViewById(R.id.student_name);
            student_no = itemView.findViewById(R.id.student_mobile);
            student_email = itemView.findViewById(R.id.student_email);
            student_class = itemView.findViewById(R.id.student_class);
        }
    }
}
