package smart.college.admin.view;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import smart.college.R;
import smart.college.admin.add.AdminHomeActivity;
import smart.college.session.UserSession;
//import smart.college.teacher.TeacherHomePage;

public class ViewStudentActivity extends AppCompatActivity {

    DatabaseReference mDatabaseReference;
    ArrayList<HashMap> allClasses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_student);


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
            }
        });


        allClasses = new ArrayList<HashMap>();

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Student");

        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (allClasses.isEmpty() == false) {
                    allClasses.clear();
                }
                allClasses = ((ArrayList<HashMap>) snapshot.getValue());

                RecyclerView recyclerView = findViewById(R.id.recycle_view);
                StudentAdapter itemAdapter = new StudentAdapter(allClasses, getApplicationContext());
                GridLayoutManager gridLayout = new GridLayoutManager(getApplicationContext(), 1);
                recyclerView.setAdapter(itemAdapter);
                recyclerView.setLayoutManager(gridLayout);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
            }
        });


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (new UserSession(getApplicationContext()).getTemp().equalsIgnoreCase("admin")) {
            finish();
            startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
        } else {
            finish();
//            startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));

        }
    }

}
