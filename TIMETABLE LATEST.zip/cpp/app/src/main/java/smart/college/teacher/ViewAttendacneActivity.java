package smart.college.teacher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import smart.college.R;
import smart.college.admin.add.AdminHomeActivity;
import smart.college.admin.view.StudentAdapter1;
import smart.college.parent.ParentHomeActivity;
import smart.college.session.UserSession;
import smart.college.student.StudentHomeActivity;

public class ViewAttendacneActivity extends AppCompatActivity {


    String teacher_class_name;
    DatabaseReference mDatabaseReference;
    Spinner all_dates_spinner;
    List<String> all_dates;
    List<Map> students;
    TextView select_date_txt;
    String attendanceDate;
    DatePickerDialog datePickerDialog;
    int attendance_key = 0;
    UserSession userSession;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendacne);

        all_dates_spinner = findViewById(R.id.all_dates_spinner);
        all_dates = new ArrayList<>();
        students = new ArrayList<>();
        select_date_txt = findViewById(R.id.select_date_txt);

        userSession = new UserSession(getApplicationContext());
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Attendance");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                all_dates.clear();
                all_dates.add("Select Date");
                for (DataSnapshot dataSnapshot : snapshot.getChildren()
                ) {
                    all_dates.add(dataSnapshot.getKey());
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, all_dates);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                all_dates_spinner.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.viewAttendance).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ArrayList<HashMap> studentList = new ArrayList<>();

                mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Attendance").child(all_dates_spinner.getSelectedItem().toString());
                mDatabaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            HashMap attendance = (HashMap) dataSnapshot.getValue();

                            if (userSession.getTemp().equalsIgnoreCase("parent") &&
                                    attendance.get("student_email").equals(userSession.getEmail())) {
                                studentList.add(attendance);
                            }

                            if (userSession.getTemp().equalsIgnoreCase("student") &&
                                    attendance.get("student_email").equals(userSession.getEmail())) {
                                studentList.add(attendance);
                            }
                            if (userSession.getTemp().equalsIgnoreCase("teacher") && attendance.get("teacher_email").equals(userSession.getEmail())) {
                                studentList.add(attendance);
                            }
                        }

//                        if (studentList.isEmpty() == false) {

                        RecyclerView recyclerView = findViewById(R.id.recycle_view);
                        StudentAdapter1 itemAdapter = new StudentAdapter1(studentList, getApplicationContext());
                        GridLayoutManager gridLayout = new GridLayoutManager(getApplicationContext(), 1);
                        recyclerView.setAdapter(itemAdapter);
                        recyclerView.setLayoutManager(gridLayout);

//                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        });


        findViewById(R.id.img_go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        if (userSession.getTemp().equalsIgnoreCase("student")) {
            startActivity(new Intent(getApplicationContext(), StudentHomeActivity.class));
        }
        if (userSession.getTemp().equalsIgnoreCase("parent")) {
            startActivity(new Intent(getApplicationContext(), ParentHomeActivity.class));
        }

        if (userSession.getTemp().equalsIgnoreCase("teacher")) {
         //   startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
        }
    }

}