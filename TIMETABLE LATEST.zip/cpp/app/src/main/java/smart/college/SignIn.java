package smart.college;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

import smart.college.admin.add.AdminHomeActivity;
import smart.college.parent.ParentHomeActivity;
import smart.college.session.UserSession;
import smart.college.student.StudentHomeActivity;
//import smart.college.teacher.TeacherHomePage;

public class SignIn extends AppCompatActivity {

    EditText email;
    EditText password;
    Boolean login;
    DatabaseReference mDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        SqliteHelper sqliteHelper = new SqliteHelper(this);
        UserSession userSession = new UserSession(getApplicationContext());

        if (userSession.getTemp().toString().equalsIgnoreCase("teacher")) {
            finish();
          //  startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
        } else if (userSession.getTemp().toString().equalsIgnoreCase("admin")) {
            finish();
            startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
        } else if (userSession.getTemp().toString().equalsIgnoreCase("student")) {
            finish();
            startActivity(new Intent(getApplicationContext(), StudentHomeActivity.class));
        } else if (userSession.getTemp().toString().equalsIgnoreCase("parent")) {
            finish();
            startActivity(new Intent(getApplicationContext(), ParentHomeActivity.class));
        }


        findViewById(R.id.alreadyHaveAccount).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SignUp.class));
            }
        });

        findViewById(R.id.logIn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Check user input is correct or not
                if (validate()) {

                    //Get values from EditText fields
                    String Email = email.getText().toString();
                    String Password = password.getText().toString();

                    login = false;

                    if (Email.contains("admin")) {
                        UserSession userSession = new UserSession(getApplicationContext());
                        userSession.setEmail("admin@gmail.com");
                        userSession.setCustomerId(0);
                        userSession.setTemp("admin");
                        userSession.setMobile("4");
                        userSession.setFirstName("admin");
                        finish();
                        startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
                    } else {

                        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
                        mDatabaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    HashMap mapList = (HashMap) dataSnapshot.getValue();
                                    if (mapList.get("email").toString().equalsIgnoreCase(Email)
                                            &&
                                            mapList.get("password").toString().equalsIgnoreCase(Password)) {

                                        UserSession userSession = new UserSession(getApplicationContext());
                                        userSession.setEmail(mapList.get("email").toString());
                                        userSession.setHomeDelivery(mapList.get("email").toString());
                                        userSession.setCustomerId(Integer.parseInt(dataSnapshot.getKey()));
                                        userSession.setTemp(mapList.get("type").toString());
                                        userSession.setMobile(mapList.get("mobile").toString());
                                        userSession.setFirstName(mapList.get("name").toString());

                                        finish();

                                        login = true;

                                        if (mapList.get("type").toString().equalsIgnoreCase("parent")) {
                                            getChildInfo();
                                        }

                                        else if (mapList.get("type").toString().equalsIgnoreCase("teacher")) {
                                           // startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
                                        } else if (userSession.getTemp().toString().equalsIgnoreCase("student")) {
                                            finish();
                                            startActivity(new Intent(getApplicationContext(), StudentHomeActivity.class));
                                        }
                                    }

                                }


                                if (login == false) {
                                    Toast.makeText(getApplicationContext(), "Invalid Credential", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();

                            }
                        });

                    }
                }

            }
        });

    }


    public void getChildInfo() {

        UserSession userSession = new UserSession(getApplicationContext());

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Parent");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    HashMap mapList = (HashMap) dataSnapshot.getValue();
                    if (mapList.get("parent_email").toString().equalsIgnoreCase(userSession.getEmail())) {

                        String childName = mapList.get("parent_student").toString();

                        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Student");
                        mDatabaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {

                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    HashMap mapList = (HashMap) dataSnapshot.getValue();
                                    if (mapList.get("student_name").toString().equalsIgnoreCase(childName)) {
                                        userSession.setEmail(mapList.get("student_email").toString());
                                        finish();
                                        startActivity(new Intent(getApplicationContext(), ParentHomeActivity.class));

                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });


                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    //This method is used to validate input given by user
    public boolean validate() {
        boolean valid = false;

        //Get values from EditText fields
        String Email = email.getText().toString();
        String Password = password.getText().toString();

        //Handling validation for Email field
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            valid = false;
            email.setError("Please enter valid email!");
        } else {
            valid = true;
            email.setError(null);
        }

        //Handling validation for Password field
        if (Password.isEmpty()) {
            valid = false;
            password.setError("Please enter valid password!");
        }

        return valid;
    }

}