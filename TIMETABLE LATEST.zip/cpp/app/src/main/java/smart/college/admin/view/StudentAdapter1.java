package smart.college.admin.view;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import smart.college.R;
import smart.college.student.ViewAndSolveAssignmentActivity;
import smart.college.teacher.UpdateAssignmentActivity;


public class StudentAdapter1 extends RecyclerView.Adapter<StudentAdapter1.ItemViewHolder> {

    private ArrayList<HashMap> mItemList;
    private Context mcontext;

    public StudentAdapter1(@NonNull ArrayList<HashMap> ItemList, Context context) {
        this.mItemList = ItemList;
        this.mcontext = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_item1, parent, false);
        return new ItemViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {

        final Map item = mItemList.get(position);
        if (item != null) {
            Log.e("Map", item.toString());
            holder.student_name.setText("Name: " + item.get("student_name").toString());
            holder.student_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mcontext, UpdateAssignmentActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("item", (Serializable) item);
                    mcontext.startActivity(intent);
                }
            });


            try {
                if (item.get("status").toString().equals("1")) {
                    holder.attendance_status.setText("Student was Present");
                    holder.attendance_status.setTextColor(Color.BLUE);
                }
                if (item.get("status").toString().equals("0")) {
                    holder.attendance_status.setText("Student was Absent");
                    holder.attendance_status.setTextColor(Color.RED);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }// End of binder function


    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView student_name, attendance_status, student_email, student_class;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            student_name = itemView.findViewById(R.id.student_name);
            attendance_status = itemView.findViewById(R.id.attendance_status);
        }
    }
}
