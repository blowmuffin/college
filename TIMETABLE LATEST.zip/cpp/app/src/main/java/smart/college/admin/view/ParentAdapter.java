package smart.college.admin.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import smart.college.R;


public class ParentAdapter extends RecyclerView.Adapter<ParentAdapter.ItemViewHolder> {

    private ArrayList<HashMap> mItemList;
    private Context mcontext;

    public ParentAdapter(@NonNull ArrayList<HashMap> ItemList, Context context) {
        this.mItemList = ItemList;
        this.mcontext = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.parent_item, parent, false);
        return new ItemViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {

        final Map item = mItemList.get(position);
        if (item != null) {
            Log.e("Map", item.toString());
            holder.parent_no.setText("Mobile: " + item.get("parent_mobile").toString());
            holder.parent_name.setText("Name: " + item.get("parent_name").toString());
            holder.parent_class.setText("Class : " + item.get("parent_student").toString());
            holder.parent_email.setText("Email : " + item.get("parent_email").toString());
        }

    }// End of binder function


    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView parent_name, parent_no, parent_email, parent_class;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            parent_name = itemView.findViewById(R.id.parent_name);
            parent_no = itemView.findViewById(R.id.parent_mobile);
            parent_email = itemView.findViewById(R.id.parent_email);
            parent_class = itemView.findViewById(R.id.parent_student);
        }
    }
}
