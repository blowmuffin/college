package smart.college.parent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import smart.college.R;
import smart.college.SignIn;
import smart.college.ViewTimeTableActivity;
import smart.college.session.UserSession;
import smart.college.student.ViewAssignmentsActivity;
import smart.college.teacher.ViewAttendacneActivity;

public class ParentHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_home);

        Log.e("sess", new UserSession(getApplicationContext()).getEmail().toString());

        findViewById(R.id.view_assignment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ViewAssignmentsActivity.class));
            }
        });

        findViewById(R.id.crd_view_time_table).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ViewTimeTableActivity.class));
            }
        });

        findViewById(R.id.my_attendance).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ViewAttendacneActivity.class));
            }
        });

        findViewById(R.id.my_profile).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ParentProfileActivity.class));
            }
        });

        findViewById(R.id.crd_logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserSession userSession = new UserSession(getApplicationContext());
                userSession.removeUser();
                finish();
                startActivity(new Intent(getApplicationContext(), SignIn.class));
            }
        });

    }
}