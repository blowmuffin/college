package smart.college.admin.add;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import smart.college.R;

public class AddClassRoom extends AppCompatActivity {

    int class_key = 0;
    DatabaseReference mDatabaseReference;
    EditText classNo, className, classLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_class_room);

        classNo = findViewById(R.id.class_no);
        className = findViewById(R.id.class_name);
        classLocation = findViewById(R.id.class_location);

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Classes");

        Query query = mDatabaseReference.orderByKey().limitToLast(1);

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot notepad : snapshot.getChildren()) {
                    class_key = Integer.parseInt(notepad.getKey().toString()) + 1;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        findViewById(R.id.btnAddClass).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (classNo.getText().toString().isEmpty() || className.getText().toString().isEmpty() || classLocation.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Provide All Fields", Toast.LENGTH_SHORT).show();
                } else {

                    Map productMap = new HashMap();
                    productMap.put("class_no", classNo.getText().toString());
                    productMap.put("class_name", className.getText().toString());
                    productMap.put("class_location", classLocation.getText().toString());


                    mDatabaseReference.child(String.valueOf(class_key))
                            .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {

                                Toast.makeText(getApplicationContext(), "Class Added Successfully", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
                            } else {
                                Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
                }

            }
        });


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
    }

}
