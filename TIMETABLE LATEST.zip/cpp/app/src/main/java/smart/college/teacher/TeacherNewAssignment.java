package smart.college.teacher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import smart.college.R;
import smart.college.admin.add.AdminHomeActivity;
import smart.college.session.UserSession;

public class TeacherNewAssignment extends AppCompatActivity {


    EditText assignment_tittle, assignment_marks, assignment_questions;
    Button submit;
    int class_key = 0;
    DatabaseReference mDatabaseReference;
    EditText classNo, className, classLocation;
    UserSession userSession;
    String teacher_class_name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_new_assignment);
        assignment_tittle = findViewById(R.id.tittle);
        assignment_marks = findViewById(R.id.marks);
        assignment_questions = findViewById(R.id.assignment_questions);
        userSession = new UserSession(getApplicationContext());


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Teacher");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Map student = (Map) dataSnapshot.getValue();
                    if (student.get("teacher_email").toString().equalsIgnoreCase(userSession.getEmail())) {
                        Log.e("Teacher ID ", dataSnapshot.toString());
                        teacher_class_name = student.get("teacher_class").toString();
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Assignments");

        Query query = mDatabaseReference.orderByKey().limitToLast(1);

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot notepad : snapshot.getChildren()) {
                    class_key = Integer.parseInt(notepad.getKey().toString()) + 1;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


        findViewById(R.id.submit_assignment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Map productMap = new HashMap();

                productMap.put("tittle", assignment_tittle.getText().toString());
                productMap.put("marks", assignment_marks.getText().toString());
                productMap.put("questions", assignment_questions.getText().toString());
                productMap.put("teacher_name", userSession.getFirstName());
                productMap.put("teacher_email", userSession.getEmail());
                productMap.put("teacher_id", userSession.getCustomerId());
                productMap.put("class", teacher_class_name);


                mDatabaseReference.child(String.valueOf(class_key))
                        .setValue(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Assignment Added Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
                        } else {
                            Toast.makeText(getApplicationContext(), "Some Issue Occur pls try again or restart the app", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });

        findViewById(R.id.img_go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
       // startActivity(new Intent(getApplicationContext(), TeacherHomePage.class));
    }
}