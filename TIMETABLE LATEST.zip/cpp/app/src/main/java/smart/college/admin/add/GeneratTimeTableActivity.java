package smart.college.admin.add;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import smart.college.R;

public class GeneratTimeTableActivity extends AppCompatActivity {

    int table_key = 0;
    int userId = 0;
    int totalMaxHrs = 0;
    DatabaseReference mDatabaseReference;
    EditText noOfHrs;
    TextView listSubject, txtFinalTimeTable;
    Spinner subjects_cmd;
    Button btnAddSubject, btnGenerateTable, btnPublishTable;
    HashMap<String, Integer> subjects;
    List<String> days = Arrays.asList("MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY");
    List<String> timinig = Arrays.asList("8:45 AM to 9:45 AM", "9:45 AM to 10:45 AM", "11 AM to 12 PM", "12 PM to 1 PM",
            "1:30 PM to 2:30 PM", "2:30 PM to 3:30 PM");
    Random random = new Random();
    HashMap<String, Object> timetable = new HashMap<String, Object>();
    TableLayout timeTableLayout; // Added TableLayout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generat_time_table);

        // Initialize views
        noOfHrs = findViewById(R.id.edtNoOfHrs);
        listSubject = findViewById(R.id.listSubject);
        subjects_cmd = findViewById(R.id.subjects);
        btnAddSubject = findViewById(R.id.btnAddSubject);
        btnGenerateTable = findViewById(R.id.btnGenerateTimeTable);
        btnPublishTable = findViewById(R.id.btnPublishTable);
        timeTableLayout = findViewById(R.id.timeTableLayout);// Initialize TableLayout

        // Initialize subjects HashMap
        subjects = new HashMap<String, Integer>();

        // Firebase initialization
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Subject");

        // Populate spinner with subjects
        List<String> classes = new ArrayList<>();
        classes.add("Select Subject");
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Log.e("Data ", snapshot.toString());
                    ArrayList<HashMap> mapList = ((ArrayList<HashMap>) snapshot.getValue());
                    for (Map map : mapList) {
                        classes.add(map.get("subject_name").toString());
                    }
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                subjects_cmd.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Please check you internet connection Or it may be server error please try after some time !!!", Toast.LENGTH_LONG).show();
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, classes);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                subjects_cmd.setAdapter(adapter);
            }
        });

        // Button to add subject
        btnAddSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (subjects_cmd.getSelectedItemPosition() == 0 || noOfHrs.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please provide all fields", Toast.LENGTH_LONG).show();
                } else {
                    if (Integer.parseInt(noOfHrs.getText().toString()) > 10 || Integer.parseInt(noOfHrs.getText().toString()) <= 0) {
                        Toast.makeText(getApplicationContext(), "Please valid hrs", Toast.LENGTH_LONG).show();
                    } else {
                        if (subjects.get(subjects_cmd.getSelectedItem()) != null) {
                            subjects.remove(subjects_cmd.getSelectedItem());
                            subjects.put(subjects_cmd.getSelectedItem().toString(), Integer.parseInt(noOfHrs.getText().toString()));
                            showListSubjects();
                        } else {
                            subjects.put(subjects_cmd.getSelectedItem().toString(), Integer.parseInt(noOfHrs.getText().toString()));
                            showListSubjects();
                        }
                    }
                }
            }
        });

        // Button to generate timetable
        btnGenerateTable.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                if (totalMaxHrs == 0) {
                    Toast.makeText(getApplicationContext(), "Please Add Subjects", Toast.LENGTH_LONG).show();
                } else if (totalMaxHrs > 30) {
                    Toast.makeText(getApplicationContext(), "Only 30 hrs time table is manageable please remove subjects hrs.", Toast.LENGTH_LONG).show();
                } else {
//                    Intent intent = new Intent(GeneratTimeTableActivity.this, Time_table.class);
//                    startActivity(intent);
                    generateTimeTable();
                    displayTimeTable(); // New function to display timetable
                }
            }
        });

        // Button to publish timetable to Firebase
        btnPublishTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Firebase database reference
                DatabaseReference timeTableRef = FirebaseDatabase.getInstance().getReference().child("TimeTable");

                // Convert timetable HashMap to JSON format and upload to Firebase
                timeTableRef.child("recent").setValue(timetable)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    // If upload is successful, show a success message
                                    Toast.makeText(GeneratTimeTableActivity.this, "Time Table Uploaded to Firebase", Toast.LENGTH_SHORT).show();
                                } else {
                                    // If upload fails, show an error message
                                    Toast.makeText(GeneratTimeTableActivity.this, "Failed to upload Time Table to Firebase", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    // Function to generate timetable
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void generateTimeTable() {
        timetable.clear();

        // Reset visibility of the button
        findViewById(R.id.btn).setVisibility(View.VISIBLE);

        // Generate timetable
        for (String subj : subjects.keySet()) {
            int counter = 0;
            for (int i = 0; i < 6; i++) {
                String randomTIming = timinig.get(i);
                String randomDay = days.get(random.ints(0, 5).findFirst().getAsInt());
                String key = randomDay + "%" + randomTIming;
                if (timetable.get(key) == null) {
                    timetable.put(key, Arrays.asList(randomDay, randomTIming, subj));
                    counter = counter + 1;
                }
                if (counter == subjects.get(subj)) {
                    break;
                }
                if (i == 5) {
                    i = -1;
                }
            }
        }
        // Save timetable locally
        saveTimetableLocally();

        // Update UI with timetable
        displayTimeTable();
        btnGenerateTable.setText("Re Generate Table");
    }

    // Function to display timetable in a TableLayout
    // Function to display timetable in a TableLayout
    // Function to display timetable in a TableLayout
    private void displayTimeTable() {
        // Clear previous timetable data
        timeTableLayout.removeAllViews();

        // Add column for days of the week
        TableRow dateRow = new TableRow(this);
        dateRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

        // Add empty cell for spacing at the top-left corner (if time column is used)
        TextView emptyCell = new TextView(this);
        emptyCell.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        dateRow.addView(emptyCell);

        // Add days as column headers
        for (String day : days) {
            TextView dateCell = new TextView(this);
            dateCell.setText(day);
            dateCell.setPadding(5, 5, 5, 5);
            dateCell.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
            dateCell.setBackgroundResource(R.drawable.table_cell_background);
            dateCell.setTextColor(getResources().getColor(R.color.black));
            dateCell.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            dateRow.addView(dateCell);
        }

        // Add the date row to the TableLayout
        timeTableLayout.addView(dateRow);

        // Add rows for subjects only
        for (String time : timinig) { // Make sure your variable name is correct, it was 'timinig' in your snippet
            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

            // Add time cell if you want to display the time slots in the first column, remove this block otherwise
            TextView timeCell = new TextView(this);
            timeCell.setText(time);
            timeCell.setPadding(5, 5, 5, 5);
            timeCell.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
            timeCell.setBackgroundResource(R.drawable.table_cell_background);
            timeCell.setTextColor(getResources().getColor(R.color.black));
            timeCell.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            row.addView(timeCell);

            // Add subject cells for each day without the time and date
            for (String day : days) {
                String key = day + "%" + time;
                String subjectKey = getValueOrDefault(timetable, key, "").toString();
                // Assume the subjectKey is in the format "date, time to time, subject (initials)"
                // You want to extract just the "subject" part

                String subject = "";
                if (!subjectKey.isEmpty()) {
                    String[] parts = subjectKey.split(", ");
                    // This assumes that the last part after splitting by ", " is the subject with initials
                    subject = parts[parts.length - 1].replaceAll("\\[.*?\\]\\s*", ""); // Remove square brackets and the content inside them
                }

                TextView subjectCell = new TextView(this);
                subjectCell.setText(subject);
                subjectCell.setPadding(5, 5, 5, 5);
                subjectCell.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                subjectCell.setBackgroundResource(R.drawable.table_cell_background);
                subjectCell.setTextColor(getResources().getColor(R.color.black));
                subjectCell.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                row.addView(subjectCell);
            }

            // Add the row to the TableLayout
            timeTableLayout.addView(row);
        }
        // ... (any other code if necessary)
    }

    // Helper method to get the value from the timetable or return default value if not found
    private Object getValueOrDefault(Map<String, ?> map, String key, Object defaultValue) {
        Object value = map.get(key);
        return (value != null) ? value : defaultValue;
    }



    // Function to display list of subjects
    public void showListSubjects() {
        totalMaxHrs = 0;
        String subjects_str = "";
        for (String key : subjects.keySet()) {
            subjects_str = subjects_str + "\n\n" + key + ": " + subjects.get(key);
            totalMaxHrs = totalMaxHrs + subjects.get(key);
        }
        subjects_str = subjects_str + "\n\n" + "Total Hrs" + ": " + totalMaxHrs;
        listSubject.setText(subjects_str);
        Toast.makeText(getApplicationContext(), "Subject Added", Toast.LENGTH_SHORT).show();
    }

    // Function to get value from HashMap or return default value if key not found
    private Object getValueOrDefault(HashMap<String, Object> map, String key, Object defaultValue) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return defaultValue;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(), AdminHomeActivity.class));
    }


    private void saveTimetableLocally() {
        // Create a new HashMap to store the timetable with all values converted to strings
        HashMap<String, String> stringTimetable = new HashMap<>();

        // Convert all values in the original timetable HashMap to strings
        for (Map.Entry<String, Object> entry : timetable.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            // Convert the value to a string and put it in the new HashMap
            String stringValue = String.valueOf(value);
            stringTimetable.put(key, stringValue);
        }

        // Convert the stringTimetable HashMap to JSON format and save it to SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("TimetablePrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("timetable", new Gson().toJson(stringTimetable));
        editor.apply();
    }



}
